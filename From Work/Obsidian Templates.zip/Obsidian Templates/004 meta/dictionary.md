%% Used by Various Complements Plugin %%
%% Documentation: https://tadashi-aikawa.github.io/docs-obsidian-various-complements-plugin/5.%20Terms/%F0%9F%93%9A%20Custom%20dictionary%20formats/ %%