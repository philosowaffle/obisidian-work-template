# 📦 Projects

```dataview
table dateformat(file.ctime, "MM/dd/yyyy") as "Start Date", dateformat(file.mtime, "MM/dd/yyyy") as "Last Worked On"
from #project and !"020 areas/000 journal 🪴" and !"004 meta" and !#meeting
where (file.ctime >= date(2024-01-01) and file.ctime <= (2024-12-31)) or (file.mtime >= date(2024-01-01) and file.mtime <= date(2024-12-31)) 
sort file.ctime
```

## 🔭 Discovery Projects
```dataview
table dateformat(file.ctime, "MM/dd/yyyy") as "Start Date", dateformat(file.mtime, "MM/dd/yyyy") as "Last Worked On"
from #project and #aor/discovery and !"020 areas/000 journal 🪴" and !"004 meta"
where (file.ctime >= date(2024-01-01) and file.ctime <= (2024-12-31)) or (file.mtime >= date(2024-01-01) and file.mtime <= date(2024-12-31)) 
sort file.ctime
```

## 🚚 Delivery Projects
```dataview
table dateformat(file.ctime, "MM/dd/yyyy") as "Start Date", dateformat(file.mtime, "MM/dd/yyyy") as "Last Worked On"
from #project and #aor/delivery and !"020 areas/000 journal 🪴" and !"004 meta"
where (file.ctime >= date(2024-01-01) and file.ctime <= (2024-12-31)) or (file.mtime >= date(2024-01-01) and file.mtime <= date(2024-12-31)) 
sort file.ctime
```

## 📐 Architect Projects
```dataview
table dateformat(file.ctime, "MM/dd/yyyy") as "Start Date", dateformat(file.mtime, "MM/dd/yyyy") as "Last Worked On"
from #project and #aor/architect and !"020 areas/000 journal 🪴" and !"004 meta"
where (file.ctime >= date(2024-01-01) and file.ctime <= (2024-12-31)) or (file.mtime >= date(2024-01-01) and file.mtime <= date(2024-12-31)) 
sort file.ctime
```

## ❔ Other
```dataview
table dateformat(file.ctime, "MM/dd/yyyy") as "Start Date", dateformat(file.mtime, "MM/dd/yyyy") as "Last Worked On"
from #project and !#aor/architect and !#aor/discovery and !#aor/delivery and !"020 areas/000 journal 🪴" and !"004 meta"
where (file.ctime >= date(2024-01-01) and file.ctime <= (2024-12-31)) or (file.mtime >= date(2024-01-01) and file.mtime <= date(2024-12-31)) 
sort file.ctime
```

# 🕐 Log
```dataviewjs

const dateRegex = /2024-[0-9][0-9]-[0-9][-0-9]/g;

let days = dv
	.pages()
	//.pages('"010 projects"')
	//.limit(3)
	.where(p => !p.file.path.includes("001 attachments"))
	.where(p => !p.file.path.includes("004 meta"))
	.where(p => p.file.lists)
	.flatMap(p => p.file.lists)
	.where(l => l.section.toString().includes("log"))
	.where(l => l.children && !l.parent)
	.groupBy(d => d.text);

let journalDays = dv
			.pages('"020 areas/000 journal 🪴"')
			//.limit(10)
			.groupBy(p => p.file.link);

function recursiveListChildren(listItem, root)
{
	dv.el("li", listItem.text, { container: root })

	if (listItem.children)
	{
		listItem.children.forEach(c => 
		{
			let nextRoot = dv.el("ul", "", { container: root });
			recursiveListChildren(c, nextRoot);
		});
	}
}

journalDays.forEach(day => 
{
	let date = day.key.path.match(dateRegex)?.[0];
	if (!date) return;
		
	dv.el("h2", day.key);

	let journalEntries = day
						.rows
						.flatMap(d => d.file.lists)
						.where(l => l.section.toString().includes("📝 Notes"));

	//if (journalEntries.length > 0)
	//{
	//	let journalRoot = dv.el("ul", "");
	//	dv.el("li", "Journal", { container: journalRoot });
	//	let nextRoot = dv.el("ul", "", { container: journalRoot });
	//journalEntries
	//		.where(e => !e.parent)
	//		.forEach(e => recursiveListChildren(e, nextRoot));
	//}

	
	let dayLogs = days.where(d => d.key.match(dateRegex)?.[0] == date);
	let childrenByFile = dayLogs
						.rows
						.children
						.groupBy(c => c.link);
	childrenByFile.forEach(c => 
		{
			let fileRoot = dv.el("ul", "");
			dv.el("li", c.key, { container: fileRoot });
			let nextRoot = dv.el("ul", "", { container: fileRoot });
			c.rows.forEach(c => recursiveListChildren(c, nextRoot));
		});
});

```