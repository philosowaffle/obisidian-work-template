
# All
```tasks
(not done) AND (status.type is not NON_TASK)
(path does not include 004 meta/templates) and (path does not include 004 meta/Help Module)
group by filename
sort by due
hide edit button
short mode
```
