1. [shortcuts](shortcuts.md)
2. [spec](../../Note%20Specification/000%20Specification%201.0.md)
3. [style](Style%20Help.md)