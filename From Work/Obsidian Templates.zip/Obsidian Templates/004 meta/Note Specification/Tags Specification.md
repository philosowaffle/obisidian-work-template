# Tags

1. Tags should be used sparingly
2. Tags should help build categories of content with the end goal of aiding search and filtering
3. Tag names **must** use `_` when delineating words
4. Tag names **must** use `/` when sub tagging
	1. i.e. `#project` and `#project/my_project`