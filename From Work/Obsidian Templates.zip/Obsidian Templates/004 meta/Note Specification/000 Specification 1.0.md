# toc

1. [Folder Organization](Folder%20Organization.md)
2. [Creating Note Files](Creating%20Note%20Files.md)
3. [Writing Notes](Writing%20Notes.md)
4. [Daily Note](Daily%20Note.md)
5. [Todo Tasks](Todo%20Tasks.md)
6. [Proposed Specification](Proposed%20Specification.md)
7. [Note Discoverability](Note%20Discoverability.md)
