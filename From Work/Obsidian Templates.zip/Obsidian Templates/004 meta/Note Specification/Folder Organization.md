1. Follow [PARA](https://dannb.org/blog/2022/obsidian-daily-note-template/)
	1. Projects
		1. A series of tasks linked to a goal, with a deadline
	2. Areas
		1. A sphere of activity with a standard to be maintained over time
		2. An Area of responsibility with actively updated documentation
	3. Resources
		1. A topic or theme of ongoing interest
		2. Documents generated from Projects
		3. Knowledge nuggets or general documentation
	4. Archive
		1. Inactive items from the other three categories

## Vault Structure Overview

I loosely follow the PARA Method when it comes to organizing my notes.  On the right you'll see my top level folders.

| Folder | Description |
|--------|-------------|
| 000 inbox | All new notes get created here by default. This is a temporary staging ground before I can organize them elsewhere. Generally this folder should always be empty. If it isn't empty, I should organize the note to the right spot. |
| 001 attachments | PDFs, Images, etc. get saved here. |
| 004 meta | Documentation about my notes. I'm not kidding. I keep notes on what plugins I'm using and why, what patterns I should follow, ideas for things I'd like to change in my process. |
| 010 projects | Active projects I am contributing to in some fashion. Generally one note per project, this represents the home page for any given project I need to regularly reference for at time. This folder is a temporary location for **active projects** only. Once a project is no longer active it moves to _040 archives._ |
| 020 areas | Other types of long-lived "home pages" or _root_ notes representing an _area_ in our company. Need a root note about the _iOS Team_? That note can live here. Need a home page note for the _E&E Org,_ this is a great place for it to live.<br><br>Note: A Project Note always has a start and an end date, where an Area Note has no time bounds. |
| 030 resources | Think of this as my actual personal Wiki. When I work on a Project, I may learn about how a service in our system works. This creates an _artifact_, a supplemental note that describes how this particular service works. This note, is a resource note. Or, maybe I stumble across a useful SQL query I want to save, that gets dumped into a Resource note. |
| 040 archives | Mostly **inactive projects** live here OR other deprecated notes. If you are one of those people who can't ever delete anything because you fear you might one day need it even though that info is outdated and wrong.... then you'll love the Archive folder, that's what it's here for. Dump notes in here and you'll always have them available, but you'll also clearly know they were archived for a reason and may represent deprecated information. |
| 050 gitignore | I backup my notes to GitHub, but there are some things I don't want sent to github, so naturally those one-off cases can be saved in the GitIgnore folder. |

### Meta Folder

If you're curious what kinds of things I could possibly put in the Meta folder, well, here ya go.  Some of these are specific to the note taking tool I use, while others are pure documentation to help me remember how and why I do things a certain way.

Documenting your note taking process may seem like a waste of time, but I think it satisfies one of my guiding principles: "_A notes system should be simple enough to empower you, not inhibit you."_

If your system is so complicated that you are overwhelmed by the idea of writing it down, then that's a red flag.  If your system is so simple that you can't imagine why you'd need to write it down, then what's the harm in documenting it? Should take 5min.

I think there's a lot of value in trying to concretely describe how and why you do something.  It can be very revealing as in introspective exercise and you might be surprised at what you find when you start retro-ing on your own perception of things.

### Projects

The projects folder is definitely where I spend most of my time.  Many of the projects I work on fall into one of three Categories so I like to organize them as such in sub folders.  I have a template I use for these project notes that I'm continuing to iterate on, but I'll cover that in more detail in a later section.

The point of this folder is to always have quick access to the things I am currently, actively, responsible for in some fashion.  "Responsible for" can be fairly broad, but generally if anything I work on is expected to take more than a day AND I expect someone will be asking me follow up questions about it, it get's a project note.

When a project is no longer active it leaves this folder and moves to the Archives folder.  Sometimes, as a preliminary step I may refactor some information out to Resource notes.  For example, if the project was to create a net new feature or to enhance an existing feature, I may go create a dedicated resource note for that Feature or update the existing one with information from this project before I archive the project.

### Areas

Don't ask me to define what an Area is, I really have no idea and tend to be kind of fast and loose with what I decide becomes an Area. These are the areas I currently have.

| Area        | Description                                                                                                                                                                                                                                                                                                                                                      |
| ----------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 000 journal | Not as spicy as it sounds. Part of my process is to create a fresh Daily Note each day. This gives me a clean slate and a dumping ground. Need to jot down something quick? Toss it in the Daily Note and re-organize it to the right place later. My Todo list usually also lives on the Daily Note. Anyway, all these Daily Notes, live in the Journal folder. |
| Codebases   | "Home Page" notes for various code bases. These tend to have things like links to their Repos, Builds, Wikis, and Admin tools. And sometimes they document specific codebase processes that should be followed.                                                                                                                                                  |
| Org         | Couple home page notes for our new fancy Org. E&E, E&E Core Product, E&E Platform Technology, various Brand Orgs, etc.                                                                                                                                                                                                                                           |
| People      | Yeah.... I tend to create a note per person I regularly interact with. Helps me keep track of who is associated with which projects, is a handy place to take notes from 1:1's, and is useful if you ever do need to make note of something specific to that person.                                                                                             |
| Teams       | Similar to Codebases and People, Teams are an entity and I make home page notes for them too with relevant links and information about their processes.                                                                                                                                                                                                          |

### Resources

Yeah, pretty much just my personal Wiki of information.  Need to know about Redshift? Looks like I have a note for that.  Curious about Bulkhead Pattern?  Guess I researched that at some point and made a note.  What about AntiGhosting Feature? Yup.  

This folder is a raw dumping ground of information.  Internally, these notes may have links back to relevant Projects or Areas, but they can stand on their own as atomic pieces of information.

Some of these notes may even be mostly empty, with nothing more than a link to the relevant public documentation or Wiki.  In this way, my notes double as a sort of bookmarks manager.

### Archives

Very similar to the Resources folder.  Mostly this folder has old Projects in it, but it also has deprecated notes that I'm too scared to delete even though I don't think the information is correct anymore (looking at you Akamai DNS Caching).

I really do actually delete notes sometimes.  But they have to be deemed unequivocally useless or actively harmful.  If I'm ever on the fence, even a little bit, it gets tossed in Archives.