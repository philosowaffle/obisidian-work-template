# Proposed
## ideas

A place to list ideas to try or implement.

1. see if Templater has ability to auto collapse sections
	1. has Templater support: https://github.com/liamcain/obsidian-creases

## in progress
> [!info]-
> A place to document new proposed specifications while in progress.

1. 🧪 Folder per active project
	1. Project index file with `project` tag
	2. This allows building dataview for projects worked over time even as they move to archived
	3. When project is done, most file can be reorganized into ARA, but Project Index file will always go to archived