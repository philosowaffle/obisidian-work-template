
1. File name **must** be clear and descriptive
2. First element in note **must** be H1 heading
	1. H1 heading **must** be the file name
4. File *may* temporarily live in the `000 inbox` folder until it can be organized
5. Once organized, file **must** reside in one of the four PARA folders.
6. File *may* have tag properties