1. First element in note **must** be H1 heading
	1. H1 heading **must** be the file name
2. A note *may* have a `log` section
	1. Log section **must** 
		1. be designated by H1 heading
		2. be the last section in the file
		3. contain unordered list of Dates and actions taken on that Date
3. A not *may* have a `todo` section
	1. Todo section **must**
		1. be designated by H1 heading
		2. be the first section in the file
		3. contain todo items related to the note

# relationships

1. Prefer links over Tags to build relationships
2. Prefer links over embeds

# Project notes

1. **Must** be created using the [project_template](project_template.md)
2. **Must** have tage `project`
3. **Must** live in the `010 projects` folder
4. **Must** be organized according to Area of Responsibility
	1. Architect
	2. Discovery
	3. Delivery