# Time Schedule
> [!info]-
> For when I need our by hour scheduling, I can add timestamped tasks here to show up in my todo list.

> [!danger] Superseded
> Currently replaced by [🧪 Day Planner](../vault%20plugins/plugins.md#🧪%20Day%20Planner).

- [x] 🕥 6:30 - 7:00 - CoreApi code for Interested In Me Grid ✅ 2025-02-24
- [x] 🕥 7:20 - 9:15 - Run ✅ 2025-02-24
- [-] 🕥 Schedule Link ✅ 2025-04-16
- [x] 🕥 6:00 - 6:30 - Check PRs ✅ 2025-03-04
- [x] 🕥  6:30-7:00 - Unit Tests ✅ 2025-03-04
- [x] 🕥 7:00-7:30 - Trash ✅ 2025-03-04
- [x] 🕥 7:30-9:00 - Shower ✅ 2025-03-04
- [x] 🕥 9:00-10:00 - Commute ✅ 2025-03-04
- [x] 🕥 10:00-12:00 - Unit Tests and submit PR ✅ 2025-03-05
- [x] 🕥 12:00-1:00 - Lunch ✅ 2025-03-05
- [x] 🕥 1:00-2:00 - CFA's ✅ 2025-03-05
- [x] 🕥 2:00-5:00 - Meetings ✅ 2025-03-05
- [x] 🕥 Friday 530 600 - Prep ✅ 2025-02-28
- [x] 🕥 Friday 600-700 - CRM Notes and Analysis ✅ 2025-02-28
- [x] 🕥 6:30-7:00 - CRM Analysis updates ✅ 2025-03-03
- [x] 🕥 7:00-8:00 - Mentor Program prep ✅ 2025-03-03
- [-] 🕥 8:00-9:00 - Run ❌ 2025-03-03
- [x] 🕥 10:00-2:00 - PoF Interest In Me Grid ✅ 2025-03-03
- [-] 🕥 2:00 - 4:00 - Next CFA ❌ 2025-03-03