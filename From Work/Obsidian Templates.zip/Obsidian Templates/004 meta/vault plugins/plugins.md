# plugins

## Broken Links
Helps identify broken links. Have it pinned in right side bar.
## Calendar

Provides the handy calendar widget =>
Also integrates with the Daily Note functionality

## ❌ Checklist

> [!danger] Uninstalled
> Realistically, my current system works fine.  Tasks are also never first class citizen in my worskpace view, so I'd always have to click a tab to see them..I'd rather just open the Daily Note or a note with a Dataview

Provides global checklist tab.


## Copy as HTML

Have this bound to `Cmd+Shft+C`.  This solves the problem of copying out of obisdian over to slack or Jira where the formatting gets completely lost.

## Dataview

Used for dynamically generated content in Notes that queries across the vault.

## ❌ Dynamic Outline
> [!danger] Uninstalled
> Kinda slow and I didn't really seem to use it all that much more than the built in outline.

Shows outline automatically as a type of floating menu.  Not sure if I will like this, but want to see anyway. This would ideally replace the default outline plugin that I often forget to look at.

## 🧪 Day Planner

[Repo](https://github.com/ivan-lednev/obsidian-day-planner?tab=readme-ov-file#where-to-get-a-google-calendar-link)

Testing out for visually time blocking my day, especially for cases where I don't need to block focus time.  Unfortunately does not integrate with Google calendar, for now I'm just manually adding my meeting blocks,

## Emoji Shortcodes

Replaced [❌ Icon Shortcodes](#❌%20Icon%20Shortcodes).

## Force Note View Mode

Handy for forcing some notes to always open in Source mode.  Currently using this for `templates` folder.

## 🧪 Iconic

Testing this out.  Still need to update Areas and some other notes to fully get emojis out of the file paths.

## 🧪 List Callouts

Adds callout highlighting to a list item based on the first character. See [list callouts](style.md#list%20callouts) style guide.

![list callouts](style.md#list%20callouts)

## Meta Bind

Provides inline UI elements that are directly bound to file properties.

## Natural Language Dates

Insert using `@today` to get quick date and link back to daily note.

```
today
tomorrow
yesterday
last <>
next <>
this <>
5 <> ago
2 <> from now
```

## ❌ Hover Editor

> [!danger] Uninstalled
> I liked it at first, but over time I got more frustrated that I had to manually close the windows and when needed I could never remember how to open the note in the main window.

Use `Cmd + E` shortcut to toggle between Reading and Editing. Opens with Reading view my default.  Handy for quickly referencing notes and even pinning them in floating panes.

## Obsidian Broken Links

Useful for auditing broken links in the vault.

## Obsidian Git

Used for [backup and sync](backup%20and%20sync.md).

## ❌ Obsidian Linter

> [!danger] Uninstalled
> Not sure I get enough value out of this to justify it.

[Lint](https://platers.github.io/obsidian-linter/) is applied on Save.  This applies several style consistency and convenience rules but the primary reason it was added was to support:
- Created Property - creates and maintains the file created property in the note frontmatter
- Modified Property - creates and maintains the last modified property in the note frontmatter

## Obsidian Link Converter

Converts Wiki Link to Markdown link on command.  Main use case is for managing my `log` sections when using the [Natural Language Dates](#Natural%20Language%20Dates) plugin.  This plugin does not support inserting links in the format I prefer, so the current workflow is:

1. Insert date as Wikilink (using custom format config) with Natural Language Dates plugin
2. `Ctrl+Shft+M` to convert link to relative path markdown link using Obsidian Link Converter

## ❌ Obsidian vimrc Support

> [!danger] Never installed

Provides additional configuration for the native vim mode support.

[Source](https://github.com/esm7/obsidian-vimrc-support)

Configuration is provided by a `.obsidian.vimrc` file at root of vault.
### go to definition

```lua
exmap definition obcommand editor:follow-link
nmap gd :definition
```

## Obsidian Periodic Notes

> [!success] Adopted

Using for Weekly, Monthly, Quarterly, and Yearly reviews.  Extends the core Daily Note feature and the [Calendar](#Calendar) plugin.

## Obsidian Tabs Plugin

> [!success] Adopted

Testing this out as an alternative to  [MCL Multi-Column CSS](style.md#MCL%20Multi-Column%20CSS).

https://github.com/xhuajin/obsidian-tabs?tab=readme-ov-file

````tabs

tab: TAB ONE
```tasks
not done
due today
 sort by priority, due
hide edit button
short mode
 ```
tab: TAB TWO
Content of TAB TWO
````

## Obsidian Web Clipper

Not a plugin but a web browser extension.  Allows clipping content from the web and saving to the vault.  Currently just using the default template and sending to `000 inbox/`.

## OmniSearch

Testing this out for more robust search.

`ctrl+S`
`ctrol+shft+S`

## ❌ Icon Shortcodes

[Docs](https://github.com/aidenlx/obsidian-icon-shortcodes)

Type `:<searchterm>` to insert icon.  Replaced by [Emoji Shortcodes](#Emoji%20Shortcodes)

## Jira Issue

[Docs](https://github.com/marc0l92/obsidian-jira-issue)

Convenience plugin for linking Jira Issues with their titles.  Uses a [personal access token](https://e2p.atlassian.net/secure/ViewProfile.jspa?selectedTab=com.atlassian.pats.pats-plugin:jira-user-personal-access-tokens) to authenticate. This token expires every year and needs to be re-created.

```sql
codeblock:jira-search

type: TABLE
limit: 50
columns: KEY, SUMMARY, TYPE, UPDATED, STATUS, ASSIGNEE, FIX_VERSIONS, NOTES, 
query: "Epic Link" in (PRODUCT-2458) and Project not in (PRODUCT) ORDER BY Project, status DESC, Rank
```

## Past Url Into Selection

Using this to ease pasting in urls.


## Plugin Update Tracker

Keeps track of Community Plugin Updates and attempts to full in the Changelog info.

## QuickAdd

Used with Templater to create new templated notes and move them to the correct folder.

## ❌ Supercharged Links

Currently disabled while testing [🧪 Iconic](#🧪%20Iconic)

## Style Setttings

Advanced style settings that work with many community Themes.

## Tasks

Provides auto-complete and metadata for Task items such as `Due Date`, `Start Date`, and `Priority`.  Additionally, provides a query language for Tasks across your vault.

- [Docs](https://publish.obsidian.md/tasks/Quick+Reference)
- [Tasks Specification](Todo%20Tasks.md)

### example queries

```tasks
not done
folder includes journal
sort by due
group by filename
hide edit button
short mode
```

## Templater

Used for advanced note templating. Currently used most heavily on 
- Daily Note template
- Project Template

## Various Complements

Used for auto-complete.  Can provide custom dictionary entries in [dictionary](dictionary.md).