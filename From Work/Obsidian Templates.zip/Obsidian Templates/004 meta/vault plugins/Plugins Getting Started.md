# Plugins Getting Started

This vault is designed to work with several community plugins. Install these from the Community Plugins section in Obsidian Settings:

#### Core Plugins (Highly Recommended)
- **Calendar** - Provides calendar widget and integrates with Daily Notes
- **Dataview** - Enables dynamic content generation and queries across the vault
- **Obsidian Periodic Notes** - Extends Daily Notes with Weekly, Monthly, Quarterly, and Yearly notes
- **OmniSearch** - Enhanced search capabilities (`Ctrl+S`, `Ctrl+Shift+S`)
- **QuickAdd** - Quick note creation with templates
- **Meta Bind** - Inline UI elements bound to file properties
- **Obsidian Tabs Plugin** - Multi-tab interface for better organization

#### Productivity Plugins
- **Jira Issue** - Link and display Jira issues (requires personal access token)

#### Quality of Life Plugins
- **Broken Links** - Identifies broken internal links
- **Copy as HTML** - Copy formatted content to clipboard (bound to `Cmd+Shift+C`)
- **Emoji Shortcodes** - Insert emojis using shortcodes
- **Force Note View Mode** - Control how notes open (source vs reading mode)
- **Natural Language Dates** - Insert dates using natural language (e.g., `@today`, `@tomorrow`)
- **Obsidian Link Converter** - Convert wiki links to markdown links (`Ctrl+Shift+M`)

>[!info]
> To learn more about all Plugins in use in this vault, see [plugins](plugins.md).