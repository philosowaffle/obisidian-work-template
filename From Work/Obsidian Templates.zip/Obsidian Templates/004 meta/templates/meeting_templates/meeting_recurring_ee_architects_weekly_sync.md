---
tags:
  - meeting/recurring/ee_architects_weekly_sync  
---
<%* 
	let filename = tp.file.title;
%># 📆 🔄 <%filename%>
**Description:** Weekly sync of E&E Architects
**People:** 
**Parent:** [[E&E Architects Weekly Sync]]

## 🔮 Outcomes


## 📢 Agenda
<%tp.file.cursor()%>

## ✍ Notes




