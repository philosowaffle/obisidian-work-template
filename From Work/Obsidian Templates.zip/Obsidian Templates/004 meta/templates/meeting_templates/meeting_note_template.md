---
tags:
  - meeting
---
<%* 
	let filename = tp.file.title;
%># 📆 <%filename%>
**Description:** 
**People:** 
**Parent:** 

## 🔮 Outcomes


## 📢 Agenda
<%tp.file.cursor()%>

## ✍ Notes




