---
created: <% tp.file.creation_date() %>
---
## <% tp.date.now('MM/DD/YY') %>
**Description:** 
**People:** 

## 🔮 Outcomes

## 📢 Agenda
<%tp.file.cursor()%>

## ✍ Notes




