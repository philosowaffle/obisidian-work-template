---
tags:
  - meeting/recurring/pof_rewire_e2p_sync  
---
<%* 
	let filename = tp.file.title;
%># 📆 🔄 <%filename%>
**Description:** Walkthrough the top feature priorities and determine which needs CFA, which can just be done.
**People:**  [[Pearson Stewart]], [[Jeremy Ruggaber]], [[Ujwala Khaire]]
**Parent:** [[../../../010 projects/Discovery/PoF Migration General Project]] / #project/pof_migration_general  

## 🔮 Outcomes


## 📢 Agenda
<%tp.file.cursor()%>

## ✍ Notes




