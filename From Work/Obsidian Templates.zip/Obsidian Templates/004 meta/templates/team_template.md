---
created: <% tp.file.creation_date() %>
---
<%* 
	let filename = tp.file.title;
	let alias = filename.split(" ")[0];
	let tag = "#people/" + filename.replaceAll(" ", "_").toLowerCase();
%># ⚽ <% filename %>  

**Team Lead/Manager:** <%tp.file.cursor()%>
**Product Lead:** 
**Org/Brand:** 
**Primary Responsibility:** 

# 🔗 links

- **Jira Boards:** 
- **Repo Urls:**
- **Admin Tools:**
- **Wikis:**
- **Google Drive:**
- **Slack Channels:

# 🧭 moc
> [!info]-
> Map of Content to more notes.

# 📓 notes
> [!info]-
> A place to start top level notes if individual note files are not needed or ready yet.

# 🛳 processes
> [!info]-
> Release schedule and processes.


# 📆 meetings
> [!info]-
> Working group meetings, and others.


# 🕐 log

- [[<% tp.file.creation_date("YYYY-MM-DD")%>]]
	- **Team Created**