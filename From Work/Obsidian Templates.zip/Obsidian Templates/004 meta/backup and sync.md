1. Backed up via [Obsidian Git](vault%20plugins/plugins.md#Obsidian%20Git)
2. Backed up to private repo on GitHub enterprise