# vault ideas

## vault

### intersting plugins
- DataCore 
	- seems to run fine side by side with dataview
- Home tab
	- search bar, recent files, etc - whenever you make new tab
- Note Toolbar
	- floating fab
- Status Bar Organizer
	- Nice QoL

### QuickAdd

- I think I understand the Capture macro now
	- Add Capture for new tasks?

## slack

- disable notifications for all MG channels except the announcement ones?