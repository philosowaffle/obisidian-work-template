| Description                           | Command                            |
| ------------------------------------- | ---------------------------------- |
| Close Tab                             | `Cmd + W`                          |
| Convert to markdown links active file | `Cmd + M`                          |
| Toggle all headers                    | `Ctrl + F` / `Ctrl + Shft + F`     |
| Go To                                 | `Cmd + T`                          |
| Open Settings                         | `Cmd + ,`                          |
| Nav Back/Forward                      | `Ctrl + [ ]`                       |
| New note from template                | `Cmd + Shft + N`                   |
| Open todays Daily note                | `Cmd + H`                          |
| Open note to the right                | `Cmd + Alt + click` or `enter`     |
| Reveal in nav Browser                 | `Ctrl + B`                         |
| Toggle Side Panels                    | `Ctrl + Alt + left/right arrow`    |
| Toggle Edit/Reading View              | `Cmd + E`                          |
| Next Tab / Prev Tab                   | `Ctrl + Tab` / `Ctrl + Shft + Tab` |


# proposed

## Mac

- CMD + TAB / CMD + SHFT + TAB
	- same as alt+tab on windows

## Slack

1. CMD + SHFT + A - Goes to all unread view 
	1. Use Tab to navigate down through the list
	2. Use Esc to mark as read 
	3. Arrows nav through individual messages, right arrow opens a thread
